<div class="col-md-12">
 	<div class="copyright">
    	<p>Copyright © 2019 . Todos los derechos reservados</p>
    </div>
</div>