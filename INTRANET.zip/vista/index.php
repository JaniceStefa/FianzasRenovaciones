<?php 
	echo  '<script> window.location ="../vista/login.php" </script>';
?>